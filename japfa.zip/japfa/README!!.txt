Hot to use this aplication 

1. Instal xampp untuk mengakses Apache dan MariaDb(MySQL)
2. simpan file japfa ke Localdisk (c) seperti berikut ini : C:\xampp\htdocs
3. setelah paste file, silakan membuka aplikasi browser anda ( Goggle chrome recomended)
	- Setelah itu buka link : localhost/phpmyadmin/
	- buat database dengan nama "japfa";
	- Setelah membuat database japfa silahkan import dabase yang ada di folder "japfa.sql"
	- dengan cara klik menu import, setelah itu klik pilih file, pilih japfa.sql yang ada di folder dan klik oke/import.
4. setelah melakukan langkah ke 3,  silahkan paste link url ini : localhost/japfa/
5. Untuk Login Sebagai Admin silahkan menggunakan account :
	Username : admin;  Password : admin123;
6. untuk sebagai Guest silahkan menggunakan account :
	Username : guest; Password : 12345; 
7. Login Sebagai Karyawan anda harus registrasi terlebih dahulu. 
8. Aplikasi ini merupakan opensource 
9. untuk mengetahui code dalam aplikasi, silahkan membuka aplikasi menggunakan text editor kesayangan anda.


Terima kasih atas perhatiannya, semoga dapat dimengerti.
untuk menanyakan masalah atau apapun hubungi :
Ragil Setiawan --> 081243505525(WA); Email (ragilstwn@student.uns.ac.id)