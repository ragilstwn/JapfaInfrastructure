-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 13 Mar 2020 pada 09.27
-- Versi Server: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `japfa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `Serialnumber` varchar(128) NOT NULL,
  `IDJenis` varchar(10) DEFAULT NULL,
  `Merek` varchar(128) DEFAULT NULL,
  `Tipe` varchar(128) DEFAULT NULL,
  `Mac` varchar(128) DEFAULT NULL,
  `Ip` varchar(128) DEFAULT NULL,
  `Tglmasuk` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis`
--

CREATE TABLE `jenis` (
  `IDJenis` varchar(20) NOT NULL,
  `JenisBuku` varchar(10) DEFAULT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `IDkaryawan` varchar(128) NOT NULL,
  `FirstName` varchar(128) NOT NULL,
  `LastName` varchar(128) NOT NULL,
  `FullName` varchar(128) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Department` varchar(128) NOT NULL,
  `Jobtitle` varchar(128) NOT NULL,
  `Divisi` varchar(128) NOT NULL,
  `Office` varchar(128) NOT NULL,
  `Mobile` varchar(25) NOT NULL,
  `Ekstensi` varchar(128) NOT NULL,
  `City` varchar(128) NOT NULL,
  `Country` varchar(128) NOT NULL,
  `Kodepost` varchar(128) NOT NULL,
  `Image` varchar(128) NOT NULL,
  `IDPetugas` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `IDMember` varchar(5) NOT NULL,
  `NamaMember` varchar(20) DEFAULT NULL,
  `Alamat` varchar(20) DEFAULT NULL,
  `Serialnumber` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `IDPeminjaman` int(11) NOT NULL,
  `IDMember` varchar(3) DEFAULT NULL,
  `IDBarang` varchar(3) DEFAULT NULL,
  `TanggalPinjam` date DEFAULT NULL,
  `TanggalHarusKembali` date DEFAULT NULL,
  `TanggalKembali` date DEFAULT NULL,
  `IDPetugas` varchar(3) DEFAULT NULL,
  `Denda` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugas`
--

CREATE TABLE `petugas` (
  `IDPetugas` varchar(128) NOT NULL,
  `Firstname` varchar(128) DEFAULT NULL,
  `Lastname` varchar(128) DEFAULT NULL,
  `NamaPetugas` varchar(32) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `Username` varchar(32) DEFAULT NULL,
  `Password` varchar(32) DEFAULT NULL,
  `role` varchar(10) NOT NULL,
  `date_created` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `petugas`
--

INSERT INTO `petugas` (`IDPetugas`, `Firstname`, `Lastname`, `NamaPetugas`, `email`, `Username`, `Password`, `role`, `date_created`) VALUES
('Admin', 'Admin', 'Japfa', 'Admin Japfa', '-', 'admin', 'admin123', 'admin', 2020),
('GUEST', '-', '-', 'Guest', '-', 'guest', '12345', 'Guest', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`Serialnumber`);

--
-- Indexes for table `jenis`
--
ALTER TABLE `jenis`
  ADD PRIMARY KEY (`IDJenis`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`IDkaryawan`),
  ADD KEY `IDPetugas` (`IDPetugas`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`IDMember`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`IDPeminjaman`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`IDPetugas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `IDPeminjaman` int(11) NOT NULL AUTO_INCREMENT;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD CONSTRAINT `fk_IDPetugas` FOREIGN KEY (`IDPetugas`) REFERENCES `petugas` (`IDPetugas`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
