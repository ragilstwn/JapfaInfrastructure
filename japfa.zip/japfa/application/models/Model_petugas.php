<?php  
	Class Model_petugas extends CI_Model{

		function getAllData(){
			return $this->db->get('petugas');
		}

		function login(){
			$pass = $this->input->post('password');
			$user = $this->input->post('username');
			$this->db->select('Password');
			$this->db->where('Username', $user);
			$query = $this->db->get('petugas')->row();
			if (!empty($query->Password)) {
				if ($pass == $query->Password) {
					return 1;
				} else { return 0; }
			} else { return 0; }
		}

		function namaPetugas(){
			$pass = $this->input->post('password');
			$user = $this->input->post('username');
			$this->db->select('*');
			$this->db->where('Username', $user);
			$query = $this->db->get('petugas')->row();
			if (!empty($query->Password)) {
				if ($pass == $query->Password) {
					return $query->NamaPetugas;
				} else { return 0; }
			} else { return 0; }	
		}
		

		function idPetugas(){
			$pass = $this->input->post('password');
			$user = $this->input->post('username');
			$this->db->select('*');
			$this->db->where('Username', $user);
			$query = $this->db->get('petugas')->row();
			if (!empty($query->Password)) {
				if ($pass == $query->Password) {
					return $query->IDPetugas;
				} else { return 0; }
			} else { return 0; }
		}
		function role(){
			$pass = $this->input->post('password');
			$user = $this->input->post('username');
			$this->db->select('*');
			$this->db->where('Username', $user);
			$query = $this->db->get('petugas')->row();
			if (!empty($query->Password)) {
				if ($pass == $query->Password) {
					return $query->role;
				} else { return 0; }
			} else { return 0; }
		}

		function date_created(){
				$pass = $this->input->post('password');
				$user = $this->input->post('username');
				$this->db->select('*');
				$this->db->where('Username', $user);
				$query = $this->db->get('petugas')->row();
				if (!empty($query->Password)) {
					if ($pass == $query->Password) {
						return $query->date_created;
						} else { return 0; }
					} else { return 0; }	
				}
		function tampilDataPaging($offset,$perpage){
			$this->db->limit($perpage,$offset);
			$this->db->select('*');
			$this->db->from('petugas');
			$this->db->order_by('IDPetugas','ASC');
			$data = $this->db->get();
			return $data->result();
		}
		function tampilData(){
			
			$this->db->select('*');
			$this->db->from('petugas');
			$this->db->order_by('IDPetugas','ASC');
			$data = $this->db->get();
			return $data->result();
		}


		function simpanData(){
			$data = array(
				'IDPetugas' => $this->input->post('idpetugas'),
				'NamaPetugas' => $this->input->post('namapetugas'),
				'Username' => $this->input->post('username'),
				'Password' => $this->input->post('password'),
				'role'	=> $this->input->post('role'));
			$this->db->insert('petugas',$data);
		}

		function hapusData($id){
		$this->db->where('IDPetugas', $id);
		$this->db->delete('petugas');
	}

		function updateData(){
		$data = array(
			'IDPetugas' => $this->input->post('idpetugas'),
			'NamaPetugas' => $this->input->post('namapetugas'),
			'Username' => $this->input->post('username'),
			'Password' => $this->input->post('password'),
			'role'	=> $this->input->post('role'));
		$this->db->where('IDPetugas',$this->input->post('idmpetugaslama'));
		$this->db->update('petugas',$data);
	}

		function dataPerBarang($id){
		$this->db->where('IDPetugas',$id);
		return $this->db->get('petugas');
	}

		function searchByID($key,$id){
			$this->db->like($key,$id);
			return $this->db->get('petugas');
		}

		function searchData($pilihan,$key){
		$this->db->select('*');
		$this->db->from('petugas');
		$this->db->like($pilihan, $key);
		$this->db->order_by('IDPetugas', 'ASC');
		$query = $this->db->get();
		return $query->result();
	}

	function all(){
		$this->db->select('*');
		$this->db->from('petugas');
		$this->db->order_by('IDpetugas','ASC');
		$data = $this->db->get();
		return $data->result();
		
	}


	} 
?>