<?php  
Class Model_barang extends CI_Model{
	
	function tampilData(){
		return $this->db->get('barang');
	}

	function tampilDataPaging($offset,$perpage){
		$this->db->limit($perpage,$offset);
		$this->db->select('*');
		$this->db->from('barang');
		$this->db->join('jenis','jenis.IDJenis = barang.IDJenis');
		$this->db->order_by('Serialnumber','ASC');
		$data = $this->db->get();
		return $data->result();
	}

	function all(){
		
		$this->db->select('*');
		$this->db->from('barang');
		$this->db->join('jenis','jenis.IDJenis = barang.IDJenis');
		$this->db->order_by('Serialnumber','ASC');
		$data = $this->db->get();
		return $data->result();
	}

	
	function simpanData(){
		$data = array(
			'Serialnumber' => $this->input->post('Serialnumber'),
			'IDJenis' => $this->input->post('idjenis'),
			'Merek' => $this->input->post('Merek'),
			'Tipe' => $this->input->post('Tipe'),
			'Mac'=> $this->input->post('Mac'),
			'Ip'=> $this->input->post('Ip'),
			'Tglmasuk' => $this->input->post('Tglmasuk'));
		$this->db->insert('barang',$data);
	}

	function hapusData($id){
		$this->db->where('Serialnumber', $id);
		$this->db->delete('barang');
	}

	function updateData(){
		$data = array(
			'Serialnumber' => $this->input->post('Serialnumber'),
			'IDJenis' => $this->input->post('idjenis'),
			'Merek' => $this->input->post('Merek'),
			'Tipe' => $this->input->post('Tipe'),
			'Mac'=> $this->input->post('Mac'),
			'Ip'=> $this->input->post('Ip'),
			'Tglmasuk' => $this->input->post('Tglmasuk'));
		$this->db->where('Serialnumber',$this->input->post('Seriallama'));
		$this->db->update('barang',$data);
	}

	function dataPerBarang($id){
		$this->db->where('Serialnumber',$id);
		$this->db->join('jenis','barang.IDJenis = jenis.IDJenis');
		return $this->db->get('barang');
	}

	function searchByID($pilihan,$key){
		$this->db->like($pilihan,$key);
		return $this->db->get('barang');
	}
	
	function searchData($pilihan,$key){
		$this->db->select('*');
		$this->db->from('barang');
		$this->db->like($pilihan, $key);
		$this->db->join('jenis', 'jenis.IDJenis = barang.IDJenis');
		$this->db->order_by('Serialnumber', 'ASC');
		$query = $this->db->get();
		return $query->result();
	}
	public function viewbarang($Serialnumber){
		$this->db->select('*');
		$this->db->from('barang');
		$this->db->where('Serialnumber', $Serialnumber);
		#$this->db->get('barang');
		$query = $this->db->get();
		return $query->result();
	}
}
?>