<?php  
	Class Model_karyawan extends CI_Model{

		function tampilData(){

			$this->db->select('*');
			$this->db->from('karyawan');
			$this->db->order_by('IDkaryawan','ASC');
			$data = $this->db->get();
			return $data->result();
		}
		function tampilData1(){

			return $this->db->get('karyawan');
		}

function all(){
		$this->db->select('*');
		$this->db->from('karyawan');
		$this->db->order_by('IDPetugas','ASC');
		$data = $this->db->get();
		return $data->result();
		
	}

	function viewkaryawan(){
		$email = $_SESSION['email'];
		$this->db->select('*');
		$this->db->from('karyawan');
		$this->db->where('Email', $email);
		$query = $this->db->get();
		return $query->result();
	}

	function updateData($image){
		$data = array(
			'IDkaryawan' => $this->input->post('idkaryawan'),
			'FirstName' => $this->input->post('firstname'),
			'LastName' => $this->input->post('lastname'),
			'FullName' => $this->input->post('FullName'),
			'Email' => $this->input->post('email'),
			'Department' => $this->input->post('departemen'),
			'Jobtitle' => $this->input->post('jobtitle'),
			'Divisi' => $this->input->post('divisi'),
			'Office' => $this->input->post('office'),
			'Mobile' => $this->input->post('mobile'),
			'Ekstensi' => $this->input->post('ekstensi'),
			'City' => $this->input->post('city'),
			'Country' => $this->input->post('country'),
			'Kodepost' => $this->input->post('Kodepost'),
			'Image' => $image);
		$this->db->where('IDkaryawan',$this->input->post('IDkaryawanlama'));
		$this->db->update('karyawan',$data);
	}
	function updateDatakaryawan($image){
		$data = array(
			
			'Jobtitle' => $this->input->post('jobtitle'),
			'Ekstensi' => $this->input->post('ekstensi'),
			'Image' => $image);
		$this->db->where('Jobtitle',$this->input->post('Jobtitlelama'));
		$this->db->update('karyawan',$data);
	}

	
	function simpanData($image){
		$data = array(
			'IDkaryawan' => $this->input->post('idkaryawan'),
			'FirstName' => $this->input->post('firstname'),
			'LastName' => $this->input->post('lastname'),
			'FullName' => $this->input->post('FullName'),
			'Email' => $this->input->post('email'),
			'Department' => $this->input->post('departemen'),
			'Jobtitle' => $this->input->post('jobtitle'),
			'Divisi' => $this->input->post('divisi'),
			'Office' => $this->input->post('office'),
			'Mobile' => $this->input->post('mobile'),
			'Mobile' => $this->input->post('mobile'),
			'Ekstensi' => $this->input->post('ekstensi'),
			'City' => $this->input->post('city'),
			'Country' => $this->input->post('country'),
			'Kodepost' => $this->input->post('Kodepost'),
			'Image' => $image,
			'IDPetugas' => $_SESSION['id']);
		$this->db->insert('karyawan',$data);
	}

	function hapusData($id){
		$this->db->where('IDkaryawan', $id);
		$this->db->delete('karyawan');
	}

	function tampilDataPaging($offset,$perpage){
		$this->db->limit($perpage,$offset);
		$this->db->select('*');
		$this->db->from('karyawan');
		$this->db->join('petugas','petugas.IDPetugas = karyawan.IDPetugas');
		$this->db->order_by('IDKaryawan','ASC');
		$data = $this->db->get();
		return $data->result();
	}

	function email(){
		$this->db->select('*');
		$this->db->from('karyawan');
		$this->db->where('IDPetugas', $_SESSION['id']);
		$data = $this->db->get();
		return $data->result();
	}

		function dataPerKaryawan($id){
		$this->db->where('IDKaryawan',$id);
		$this->db->join('petugas','karyawan.IDPetugas = petugas.IDPetugas');
		return $this->db->get('karyawan');
	}

	function searchByID($pilihan,$key){
		$this->db->like($pilihan,$key);
		return $this->db->get('karyawan');
	}
	function searchData($pilihan,$key){
		$this->db->select('*');
		$this->db->from('karyawan');
		$this->db->like($pilihan, $key);
		$this->db->order_by('IDkaryawan', 'ASC');
		$query = $this->db->get();
		return $query->result();
	}

}

?>