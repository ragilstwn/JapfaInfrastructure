<!DOCTYPE html>
<html>
<head>
    <title>Update Data</title>
</head>
<body>
<div class="panel panel-default">
    <div class="panel-heading">
        <strong><i class="fa fa-th-list fa-fw"></i>Update Data</strong> 
    </div>
    <form role="form" method="POST" action="<?php echo base_url() ?>index.php/controller_karyawan/edit" enctype="multipart/form-data">
        <?php 
        $key = null;
        foreach ($karyawan as $keyas) {
            if($keyas->IDPetugas == $_SESSION['id']){
                $key = $keyas;
            }
            
        }?>
        <div class="panel-body">
        <div class="form-group">
            <label>Job Title</label>
            <input class="form-control" name="jobtitle" value="<?php echo $key->Jobtitle;?>" required="required">
        </div>
       
        <div class="form-group">
            <label>Ekstesi</label>
            <input class="form-control" name="ekstensi" value="<?php echo $key->Ekstensi;?>" required="required">
        </div>
        
        <div class="form-group ">
            <div class="row">
              <label for="Image" class="col-sm-2 col-form-label">Change Foto</label>
              <div class="col-sm-10">
                  <input type="file" class="form-control-file" name="Image">
              </div>
              </div>
          </div>
          <div class="text-right">
         <input type="hidden" name="Jobtitlelama" value="<?php echo $key->Jobtitle;?>">
        <button type="submit" name="submit" class="btn btn-danger">Update</button>
        <button type="reset" class="btn btn-danger">Reset</button></div>
    </form>
    </div>
</div>
</body>
</html>


            

        