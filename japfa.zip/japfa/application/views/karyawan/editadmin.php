<!DOCTYPE html>
<html>
<head>
	<title>Update Data</title>
</head>
<body>
<div class="panel panel-default">
	<div class="panel-heading">
        <strong>Update Data</strong> | <?php echo anchor('controller_karyawan/Datakaryawan','Cancel', 'class="btn btn-danger btn-xs"');  ?>
    </div>
    <?php  
        $data = $karyawan->result()[0];
    ?>
    <div class="panel-body">
	<form role="form" method="POST" action="editadmin" enctype="multipart/form-data">
        <div class="form-group">
            <label>First Name </label>
            <input class="form-control" name="firstname" required="required" value="<?php echo $data->FirstName;?>" >
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input class="form-control" name="lastname" value="<?php echo $data->LastName;?>" required="required">
            
        </div>
        <div class="form-group">
            <label>Full Name</label>
            <input class="form-control" name="FullName" value="<?php echo $data->FullName;?>" required="required">
        </div>
        <div class="form-group">
            <label>NIK</label>
            <input class="form-control" name="idkaryawan" required="required" value="<?php echo $data->IDkaryawan;?>">
            
        </div>
        <div class="form-group">
            <label>Email</label>
            <input class="form-control" name="email" value="<?php echo $data->Email;?>" required="required">
           
        </div>
   
        <div class="form-group">
            <label>Department</label>
            <select class="form-control" name="departemen" value="<?php echo $data->Department;?>">
                <option>Analysis</option>
                <option>Animal Nutrition</option>
                <option>BOD</option>
                <option>Bussiness Development</option>
                <option>Cashier</option>
                <option>Civil</option>
                <option>Cold Storage</option>
                <option>Coord.Farm</option>
                <option>Environment Control</option>
                <option>Executive : BOD</option>
                <option>Exim</option>
                <option>Exim & Marketing</option>
                <option>Farm</option>
                <option>Finance & Accounting</option>
                <option>General Affairs</option>
                <option>Government Relation</option>
                <option>Head Of Section General Affairs</option>
                <option>HOD</option>
                <option>HOU</option>
                <option>HR & GA</option>
                <option>Human Resource</option>
                <option>Insurance</option>
                <option>Internal Audit </option>
                <option>IT</option>
                <option>LAB</option>
                <option>Land Acquisition</option>
                <option>Legal</option>
                <option>Logistics</option>
                <option>Management Information System</option>
                <option>Marketing</option>
                <option>Marketing Promotion</option>
                <option>Mechanical Promotion</option>
                <option>Mechanical Electrical</option>
                <option>Milk Processing</option>
                <option>Nursery</option>
                <option>Nutritionist</option>
                <option>Plant</option>
                <option>Plant Maintenance</option>
                <option>PPIC</option>
                <option>Procurement</option>
                <option>Production</option>
                <option>Production & Project Development</option>
                <option>Production Planning & Services</option>
                <option>Project</option>
                <option>Project Development</option>
                <option>Purchasing</option>
                <option>Quality Control</option>
                <option>R & D</option>
                <option>Region</option>
                <option>RPA</option>
                <option>Sales</option>
                <option>Secretariat</option>
                <option>Strategic Business Development</option>
                <option>Supply Chain</option>
                <option>Supporting</option>
                <option>System Operating Procedure</option>
                <option>System Procedure & Internal Control</option>
                <option>Technician</option>
                <option>Technical Service</option>
                <option>Warehouse</option>
            </select>
        </div>
        <div class="form-group">
            <label>Job Title</label>
            <input class="form-control" name="jobtitle" value="<?php echo $data->Jobtitle;?>" required="required">
        </div>
        <div class="form-group">
            <label>Divisi Jabatan</label>
            <select class="form-control" name="divisi" value="<?php echo $data->Divisi;?>">
                <option>Poultry Feed</option>
                <option>Poultry Breeding</option>
            </select>
        </div>
        <div class="form-group">
            <label>Office</label>
            <input class="form-control" name="office" value="<?php echo $data->Office;?>" required="required">
        </div>
         <div class="form-group">
            <label>Phone Number</label>
            <input class="form-control" name="mobile" value="<?php echo $data->Mobile;?>" required="required">
        </div>
       <div class="form-group">
            <label>Ekstesi</label>
            <input class="form-control" name="ekstensi" value="<?php echo $data->Ekstensi;?>" required="required">
        </div>
        <div class="form-group">
            <label>City</label>
            <input class="form-control" name="city" value="<?php echo $data->City;?>" required="required">
        </div>
        <div class="form-group">
            <label>Country</label>
            <select class="form-control" name="country" value="<?php echo $data->Country;?>">
                <option>Indonesia</option>
                <option>China</option>
                <option>India</option>
                <option>Myanmar</option>
                <option>Singapore</option>
                <option>Vietnam</option>
                <option>Bangladesh</option>
            </select>
        </div>
        <div class="form-group">
            <label>KodePos</label>
            <input class="form-control" name="Kodepost" value="<?php echo $data->Kodepost;?>" required="required">
        </div>
        <div class="form-group ">
              <label for="Image" class="col-sm-2 col-form-label">Change Foto</label>
              <div class="col-sm-10">
                  <input type="file" class="form-control-file" name="Image">
              </div>
          </div>
        <input type="hidden" name="IDkaryawanlama" value="<?php echo $data->IDkaryawan;?>">
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        <button type="reset" class="btn btn-primary">Reset</button>
    </form>
    </div>
</div>
</body>
</html>


			