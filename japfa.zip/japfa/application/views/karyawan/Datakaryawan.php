<style>
/* Style buttons */
.btn {
  background-color: DodgerBlue; /* Blue background */
  border: none; /* Remove borders */
  color: white; /* White text */
  padding: 5px 16px; /* Some padding */
  font-size: 16px; /* Set a font size */
  cursor: pointer; /* Mouse pointer on hover */
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}

.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 10000000; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 40%; /* Could be more or less, depending on screen size */
}
/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}


</style>

<body>
		<div class="col-lg-12 ">
            <div class="panel-body">
                <div class="col-md-6">
                    <a href='<?php echo base_url() ?>index.php/controller_karyawan/downloadData'><button class="btn"><i class="fa fa-download" ></i> Generate Report</button></a>
              </div>
            <form method="POST" action="<?php echo base_url() ?>index.php/controller_karyawan/search">
                <div class="col-md-3 col-md-offset-6 col-xs-12">
                </div>
                <div class="col-md-3 col-xs-12 input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search by NIK" name="key">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" type="submit" name="search">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                </div>
            </form>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <strong>Data Karyawan</strong> | Total: <?php echo $jumlah; ?> 
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nama Karyawan</th>
    								<th>NIK</th>
                                    <th>Email</th>
                                    <th>Department</th>
                                    <th>Jobtitle</th>
                                    <th>Divisi</th>
    								<th>Office</th>
                                    <th>Mobile</th>
                                    <th>Ekstensi</th>
                                    <th>City</th>
                                    <th>Country</th>
                                    <th>Kode Pos</th>
    								<th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php foreach ($karyawan as $key) { ?>
                            		<tr>
                                    	<td><?php echo $key->FullName; ?></td>
                                    	<td><?php echo $key->IDkaryawan; ?></td>
                                        <td><?php echo $key->Email; ?></td>
                                        <td><?php echo $key->Department; ?></td>
                                        <td><?php echo $key->Jobtitle; ?></td>
                                        <td><?php echo $key->Divisi; ?></td>
                                    	<td><?php echo $key->Office; ?></td>
                                        <td><?php echo $key->Mobile; ?></td>
                                        <td><?php echo $key->Ekstensi; ?></td>
                                        <td><?php echo $key->City; ?></td>
                                        <td><?php echo $key->Country; ?></td>
                                        <td><?php echo $key->Kodepost; ?></td>
                                    	<td><?php echo anchor('controller_karyawan/editadmin/'.$key->IDkaryawan, "<i class=\"fa fa-pencil-square-o\"></i>"); ?> | <?php echo anchor('controller_karyawan/delete/'.$key->IDkaryawan, "<i class=\"fa fa-trash\"></i>", "onclick=\"return confirm('Are you sure? Delete this data?');\""); ?></td>
                                	</tr>	
                            	<?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
    	<?php echo $paging ?>
    </div>
</body>