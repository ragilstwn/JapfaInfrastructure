
<style>
.card {
        margin: 0 auto; /* Added */
        float: none; /* Added */
        margin-bottom: 10px; /* Added */
        margin-top: 30px;
}
.card-img {
    width: 100%;
    height: 15vw;
    object-fit: cover;
}
</style>

<body>
        <div class="col-lg-12">   
        <div class="card mb-3" style="max-width: 540px;">
          <div class="row no-gutters">
            <div class="col-md-4">
              <img src="<?= base_url('assets/img/profile/default.jpg');?>" class="card-img" >
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title"><?= $_SESSION['nama'];?></h5>
                <p class="card-text">Acobaco@gmail.com</p>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Registered <?= date('d F Y');?></small></p>
              </div>
            </div>
          </div>
        </div>


        </div>
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-striped table-condensed">
                    
                            <?php foreach ($karyawan as $key) { ?>
                                <tr>
                                    <th>Fullname</th>
                                    <td><?= $key->Fullname; ?></td></tr>
                                <tr>
                                    <th>NIK</th>
                                    <td><?php echo $key->idkaryawan; ?></td></tr>
                                <tr>
                                    <th>Department</th>
                                    <td><?php echo $key->departemen; ?></td></tr>
                                <tr>
                                    <th>Jobtitle</th>
                                    <td><?php echo $key->jobtitle; ?></td></tr>
                                <tr>
                                    <th>Divisi</th>
                                    <td><?php echo $key->divisi; ?></td></tr>
                                <tr>
                                    <th>Office</th>
                                    <td><?php echo $key->office; ?></td></tr>
                                <tr>
                                    <th>Ekstensi</th>
                                    <td><?php echo $key->ekstensi; ?></td></tr>
                                <tr>
                                    <th>Bill Area</th>
                                    <td><?php echo $key->billarea; ?></td></tr>
                                <tr>
                                    <th>Location</th>
                                    <td><?php echo $key->location; ?></td></tr>
                                <tr>
                                     <th>Kode Pos</th>
                                    <td><?php echo $key->kodepost; ?></td></tr>
                                </tr>
                              <?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
    	 <?php echo anchor('controller_karyawan/edit/'. $IDkaryawan,'Update Data Diri', 'class="btn btn-outline btn-danger btn-xs"') ?> 
    </div>
</body>