<?php 
	include_once("PHP_XLSXWriter/xlsxwriter.class.php");

	ini_set('display_errors', 0);
	ini_set('log_errors', 1);
	error_reporting(E_ALL & ~E_NOTICE);
	$filename = "Data Karyawan PT. Japfa Comfeed (".date("Y-m-d H:i:s").").xlsx";
header('Content-disposition: attachment; filename="' .XLSXWriter::sanitize_filename($filename). '"');
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate');
header('Pragma: public');
$jam = date("H:i:s");

$header = array(
	''=>'string',//text
  	'Generated At'=>'string',
  	$jam =>'string'
);

$rows = [];

$namakaryawan = 'unknown';

	foreach($alldata as $row){
		foreach($datakaryawan as $eachkaryawan){
			if($eachkaryawan->IDPetugas == $row->IDkaryawan){
				$namakaryawan = $eachkaryawan->Password;
			}
		}
		
      	array_push($rows,array($request, $request,$row->IDkaryawan,$row->FirstName, $row->LastName, $row->FullName, $row->Email, $row->Mobile, $row->Department, $row->Jobtitle, $row->Divisi, $row->Office, $row->Ekstensi, $row->City, $row->Country, $row->Kodepost, $row->Password));
    	$no++;
    }
$writer = new XLSXWriter();
$writer->setAuthor('Panerus UNS');
$writer->writeSheetHeader('Sheet1',$header,$col_opt=['widths'=>[10,15,10],'supress_row'=>true]);
$writer->writeSheetRow('Sheet1',array("Request","Request Status","NIK","FirstName","LastName","FullName","Email","No.Telp","Department","Jobtitle", "Divisi Karyawan","OfficeExt", "Ekstensi","City","Country","KodePost","Password"));
foreach($rows as $row){
	$writer->writeSheetRow('Sheet1', $row);
}
$writer->writeToStdOut();
//$writer->writeToFile('example.xlsx');
//echo $writer->writeToString();
exit(0);
?>