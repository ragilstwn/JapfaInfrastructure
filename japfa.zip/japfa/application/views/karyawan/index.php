<body>
        <div class="container">
                <div class="row">
                <div class="col-md-8">    
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered detail-view">
                            <tbody>
							<?php
                                $key = null;
								foreach ($petugas as $keya) {
								if($keya->IDPetugas == $_SESSION['id']){
									$key = $keya;
								}
			
							}?>
                                <tr>
                                    <th>NIK</th>
                                    <td><?= $key->IDkaryawan; ?></td></tr>
                                <tr>
                                    <th>Nama</th>
                                    <td><?php echo $key->FullName; ?></td></tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo $key->Email; ?></td></tr>
                                <tr>
                                    <th>Job Title</th>
                                    <td><?php echo $key->Jobtitle; ?></td></tr>
                                <tr>
                                    <th>Divisi</th>
                                    <td><?php echo $key->Divisi; ?></td></tr>
                                <tr>
                                    <th>Phone Number</th>
                                    <td><?php echo $key->Mobile; ?></td></tr>
        
                              
                            </tbody>
                        </table>
                    </div>
                </div>  
                <div class="col-md-4">
                    <img src="<?php  echo base_url(); ?>/assets/img/profile/<?php echo $key->Image; ?>" width="150" height="180" alt>
                    
                </div>          <!-- /.table-responsive -->
                </div>
                         <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
       <!---/ Body Riwayat--->
       <div class="row">
        <div class="page-header">
            <h3>
                <i class="fa fa-th-list"></i> Riwayat
            </h3>
            <p>Berikut ini adalah data riwayat biodata Karyawan PT.Japfa Comfeed</p>
        </div>
        <div class="tab-content">
            <div class="tab-pane active">
                <table class="table table-striped table-bordered detail-view">
                    <tbody>
                        <tr>
                            <th>NIM</th>
                            <td><?= $key->IDkaryawan; ?></td>
                        </tr>
                        <tr>
                            <th>Nama Depan</th>
                            <td><?= $key->FirstName;?></td>
                        </tr>
                        <tr>
                            <th>Nama Belakang</th>
                            <td><?= $key->LastName;?></td>
                        </tr>
                        <tr>
                            <th>Nama Lengkap</th>
                            <td><?= $key->FullName;?></td>
                        </tr>
                        <tr>
                            <th>Alamat Email</th>
                            <td><?= $key->Email;?></td>
                        </tr>
                        <tr>
                            <th>Department</th>
                            <td><?= $key->Department;?></td>
                        </tr>
                        <tr>
                            <th>Job Title</th>
                            <td><?= $key->Jobtitle;?></td>
                        </tr>
                        <tr>
                            <th>Divisi</th>
                            <td><?= $key->Divisi;?></td>
                        </tr>
                        <tr>
                            <th>City</th>
                            <td><?= $key->City;?></td>
                        </tr>
                        <tr>
                            <th>Office</th>
                            <td><?= $key->Office;?></td>
                        </tr>
                        <tr>
                            <th>Ekstensi</th>
                            <td><?= $key->Ekstensi;?></td>
                        </tr>
                        <tr>
                            <th>Country</th>
                            <td><?= $key->Country;?></td>
                        </tr>
                        <tr>
                            <th>Kode Pos</th>
                            <td><?= $key->Kodepost?></td>
                        </tr>

                    </tbody>
                </table>
            </div>
            
        </div>

            <?php echo anchor('controller_karyawan/edit','Update', 'class="btn btn-outline btn-danger"') ?>
       </div>
    <div>
       
    </div>
</body>