<body>
        <div class="col-lg-12">
            
            </div>
            <div class="panel panel-default">
                
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nama Karyawan</th>
                                    <th>NIK</th>
                                    <th>Email</th>
                                    <th>Department</th>
                                    <th>Jobtitle</th>
                                    <th>Divisi</th>
                                    <th>Office</th>
                                    <th>Mobile</th>
                                    <th>Ekstensi</th>
                                    <th>City</th>
                                    <th>Country</th>
                                    <th>Kode Pos</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($karyawan as $key) { ?>
                                    <tr>
                                        <td><?php echo $key->FullName; ?></td>
                                        <td><?php echo $key->IDkaryawan; ?></td>
                                        <td><?php echo $key->Email; ?></td>
                                        <td><?php echo $key->Department; ?></td>
                                        <td><?php echo $key->Jobtitle; ?></td>
                                        <td><?php echo $key->Divisi; ?></td>
                                        <td><?php echo $key->Office; ?></td>
                                        <td><?php echo $key->Mobile; ?></td>
                                        <td><?php echo $key->Ekstensi; ?></td>
                                        <td><?php echo $key->City; ?></td>
                                        <td><?php echo $key->Country; ?></td>
                                        <td><?php echo $key->Kodepost; ?></td>
                                    </tr>  
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
        <?php echo anchor('controller_karyawan/Datakaryawan','Back', 'class="btn btn-outline btn-danger btn-xs"') ?>
    </div>
</body>