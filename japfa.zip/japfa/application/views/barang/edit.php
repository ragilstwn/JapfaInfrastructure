<!DOCTYPE html>
<html>
<head>
	<title>Update Data</title>
</head>
<body>
<div class="panel panel-default">
	<div class="panel-heading">
        <strong>Update Data</strong> | <?php echo anchor('controller_barang','Cancel', 'class="btn btn-danger btn-xs"');  ?>
    </div>
    <?php  
        $data = $barang->result()[0];
    ?>
    <div class="panel-body">
	<form role="form" method="POST" action="edit">
        <div class="form-group">
           	<label>SerialNumber</label>
            <input class="form-control" name="Serialnumber" required="required" value="<?php echo $data->Serialnumber;?>">
        </div>
         <div class="form-group">
            <label>Hardware Resource</label>
            <select class="form-control" name="idjenis">
            <option value="<?php echo $data->IDJenis; ?>"><?php echo $data->JenisBuku; ?></option>
            <?php foreach ($jenis as $key) { ?>
                <option value="<?php echo $key->IDJenis ; ?>"><?php echo $key->JenisBuku; ?></option>
            <?php } ?>   
            </select>
        </div>
        <div class="form-group">
           	<label>Merek</label>
            <input class="form-control" name="Merek" required="required" value="<?php echo $data->Merek;?>">
        </div>
        <div class="form-group">
            <label>Tipe</label>
            <input class="form-control" name="Tipe" required="required" value="<?php echo $data->Tipe;?>">
        </div>
        <div class="form-group">
            <label>MAC Address</label>
            <input class="form-control" name="Mac" required="required" value="<?php echo $data->Mac;?>">
        </div>
        <div class="form-group">
            <label>IP Address</label>
            <input class="form-control" name="Ip" required="required" value="<?php echo $data->Ip;?>">
        </div>
        <div class="form-group">
          	<label>Tanggal Masuk</label>
            <input type="Date" class="form-control" name="Tglmasuk" required="required" value="<?php echo $data->Tglmasuk;?>">
        </div>
  
        <input type="hidden" name="Seriallama" value="<?php echo $data->Serialnumber;?>">
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        <button type="reset" class="btn btn-primary">Reset</button>
    </form>
    </div>
</div>
</body>
</html>


			