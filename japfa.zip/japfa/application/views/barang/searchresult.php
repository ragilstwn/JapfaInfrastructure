<body>
		<div class="col-lg-12">
            <div class="panel-body">
            <form method="POST" action="<?php echo base_url() ?>index.php/controller_barang/search">
                <div class="col-md-3 col-md-offset-6 col-xs-12">
                    <div class="form-group">
                        <select class="form-control" name="pilihan">
                            <option value="Serialnumber">Item's ID</option>
                            <option value="Tipe">Tipe</option>    
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-xs-12 input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search..." name="key">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" type="submit" name="search">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                </div>
            </form>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <strong>Item List</strong> | Total: <?php echo $jumlah; ?> 
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Serial Number</th>
                                    <th>Hardware Resource</th>
                                    <th>Merek</th>
                                    <th>Tipe</th>
                                    <th>MAC Address</th>
                                    <th>IP Address</th>
                                    <th>Tanggal Masuk</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php foreach ($barang as $key) { ?>
                            		<tr>
                                    	<td><?php echo $key->Serialnumber; ?></td>
                                        <td><?php echo $key->JenisBuku; ?></td>
                                        <td><?php echo $key->Merek; ?></td>
                                        <td><?php echo $key->Tipe; ?></td>
                                        <td><?php echo $key->Mac; ?></td>
                                        <td><?php echo $key->Ip; ?></td>
                                        <td><?php echo $key->Tglmasuk; ?></td>
                                    	<td><?php echo anchor('controller_barang/edit/'.$key->Serialnumber, "<i class=\"fa fa-pencil-square-o\"></i>"); ?> | <?php echo anchor('controller_barang/delete/'.$key->Serialnumber, "<i class=\"fa fa-trash\"></i>", "onclick=\"return confirm('Are you sure? Delete this data?');\""); ?></td>
                                	</tr>	
                            	<?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
    	<?php echo anchor('controller_barang','Back', 'class="btn btn-outline btn-danger btn-xs"') ?>
    </div>
</body>