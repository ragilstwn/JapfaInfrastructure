<!DOCTYPE html>
<html>
<head>
	<title>Insert Data</title>
</head>
<body>
<div class="panel panel-default">
	<div class="panel-heading">
        <strong>Insert Data Server</strong> | <?php echo anchor('controller_barang','Cancel', 'class="btn btn-danger btn-xs"');  ?>
    </div>
    <div class="panel-body">
	<form role="form" method="POST" action="add">
        <div class="form-group">
           	<label>Serial Number</label>
            <input class="form-control" name="Serialnumber" placeholder="Insert new Serialnumber" required="required">
        </div>
         <div class="form-group">
            <label>Hardware Resource</label>
            <select class="form-control" name="idjenis">
            <?php foreach ($jenis as $key) { ?>
                <option value="<?php echo $key->IDJenis; ?>"><?php echo $key->JenisBuku; ?></option>
            <?php } ?>
            </select>
        </div>
        <div class="form-group">
          	<label>Merek</label>
            <input class="form-control" name="Merek" placeholder="Insert the Item's Merek" required="required">
        </div>
        <div class="form-group">
            <label>Tipe</label>
            <input class="form-control" name="Tipe" placeholder="Insert new Item' Tipe" required="required">
        </div>
        <div class="form-group">
            <label>MAC Address</label>
            <input class="form-control" name="Mac" placeholder="Insert Mac Address xx-xx-xx-xx-xx-xx" required="required">
        </div>
        <div class="form-group">
            <label>IP Address</label>
            <input class="form-control" name="Ip" placeholder="Insert IP Address xxx.xxx.xxx.xxx" required="required">
        </div>
        <div class="form-group">
            <label>Tanggal Masuk</label>
            <input type="Date" class="form-control" name="Tglmasuk" placeholder="Insert the Item's Date of Entry DD-MM-YYY" required="required">
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        <button type="reset" class="btn btn-primary">Reset</button>
    </form>
    </div>
</div>
</body>
</html>


			