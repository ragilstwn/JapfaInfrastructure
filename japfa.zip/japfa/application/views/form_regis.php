<div class="panel-heading">
     <h3 class="panel-title" style="text-align: center;">Create a New Account</h3>
</div>
<div class="panel-body">
    <form class="user"  method="POST" action= "<?php echo base_url() ?>index.php/controller_auth/registration">
    <fieldset>
        <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control " id="Firstname" name="Firstname" placeholder="Firstname"value="<?= set_value('Firstname') ?>"> 
                  </div>
                  <div class="col-sm-6">
                    <input type="text" class="form-control" id="Lastname" name="Lastname" placeholder="Lastname" value="<?= set_value('Lastname') ?>">
                  </div>
                </div>
            <div class="form-group">
                  <input type="text" class="form-control " id="namapetugas" name="NamaPetugas" placeholder="Full Name" value="<?= set_value('NamaPetugas') ?>" > </div>
                  <div class="form-group">
                    <input type="text" class="form-control " id="Idpetugas" name="IDPetugas" placeholder="NIK"value="<?= set_value('IDPetugas') ?>"> 
                  </div>
            <div class="form-group">
                  <input type="text" class="form-control " id="email" name="email" placeholder="Email Address" value="<?= set_value('email') ?>" > 
                </div>
             <div class="form-group">
                  <input type="text" class="form-control " id="username" name="Username" placeholder="Username" value="<?= set_value('Username') ?>" > 
                </div>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="password" class="form-control form-control-user" id="password1" name="password1" placeholder="Password"> <?= form_error('password1','<small class="text-danger pl-3">','</small>') ?>
                  </div>
                  <div class="col-sm-6">
                    <input type="password" class="form-control form-control-user" id="password2" name="password2" placeholder="Repeat Password">
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-user btn-block">
                  Register Account
               </button>
    </fieldset>
    </form>
    <div class="text-center">
                <a class="small" href="<?= base_url('index.php/Controller_auth/login');?>">Already have an account? Login!</a>
              </div>
</div>