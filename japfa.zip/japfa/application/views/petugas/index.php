<body>
        <div class="col-lg-12">
            <!-- <div class="panel-body">
            <form method="POST" action="<?php echo base_url() ?>index.php/controller_member/search">
                <div class="col-md-3 col-md-offset-6 col-xs-12">
                    <div class="form-group">
                        <select class="form-control" name="pilihan">
                            <option value="IDMember">Owner's ID</option>   
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-xs-12 input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search..." name="key">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" type="submit" name="search">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                </div>
            </form>
            </div> -->
            <p><?php echo anchor('controller_petugas/add', 'Add new Item','class="btn btn-outline btn-primary btn-lg"'); ?></p>
            <div class="panel panel-green">
                <div class="panel-heading">
                    <strong>Petugas List</strong> | Total: <?php echo $jumlah; ?> 
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID Petugas</th>
                                    <th>Nama Petugas</th>
                                    <th>Username</th>
                                    <th>role</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($petugas as $key) { ?>
                                    <tr>
                                        <td><?php echo $key->IDPetugas; ?></td>
                                        <td><?php echo $key->NamaPetugas; ?></td>
                                        <td><?php echo $key->Username; ?></td>
                                        <td><?php echo $key->role; ?></td>
                                        <td><?php echo anchor('controller_member/edit/'.$key->IDPetugas, "<i class=\"fa fa-pencil-square-o\"></i>"); ?> | <?php echo anchor('controller_member/delete/'.$key->IDPetugas, "<i class=\"fa fa-trash\"></i>", "onclick=\"return confirm('Are you sure? Delete this data?');\""); ?></td>
                                    </tr>   
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
        <?php echo $paging ?>
    </div>
</body>