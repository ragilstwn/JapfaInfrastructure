<!DOCTYPE html>
<html>
<head>
	<title>PT. JAPFA COMFEED SIDOARJO</title>
</head>
<body>
<?php function halos(){if($_SESSION['role']=='Guest'){echo " style='display : none' ";}}?> 
<?php function hai(){if($_SESSION['role']=='Karyawan'){echo "style='display : none'";}} ?>
<?php function ha(){if($_SESSION['role']=='admin'){echo "style='display : none'";}} ?>
	<div class="row">
                    <div class="col-lg-3 col-md-6" <?php halos(); ?> <?php hai(); ?>>
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-sitemap fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $barang; ?></div>
                                        <div><b>Infrastructure Data</b></div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo base_url();?>index.php/controller_barang/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                     <div class="col-lg-3 col-md-6"  <?php halos(); ?> <?php hai(); ?>>
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-bookmark fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $jenis; ?></div>
                                        <div><b>KATEGORI</b></div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo base_url();?>index.php/controller_jenis/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6"  <?php halos(); ?> <?php hai(); ?>>
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-user-plus fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $member; ?></div>
                                        <div><b>Owner</b></div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo base_url();?>index.php/controller_member/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6" <?php hai(); ?>>
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa fa-desktop fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $barang; ?></div>
                                        <div><b>Report</b></div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo base_url();?>index.php/Controller_report/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div <?php ha(); ?> <?php halos();?>>
            <p>
                <br>
                <h1 style="text-align: center;">SELAMAT DATANG DI EMPLOYEE APP ONLINE</h1>
           
           
            </div>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                 <footer class="sticky-footer bg-white">
                <div class="copyright text-center my-auto"> 
      <span>Copyright &copy; Japfa Comfeed <?= date('Y');?></span>     
        </div>
    </footer>
</body>
</html>