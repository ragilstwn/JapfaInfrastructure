<style>
/* Style buttons */
.btn {
  background-color: DodgerBlue; /* Blue background */
  border: none; /* Remove borders */
  color: white; /* White text */
  padding: 5px 16px; /* Some padding */
  font-size: 16px; /* Set a font size */
  cursor: pointer; /* Mouse pointer on hover */
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}

.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 10000000; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 40%; /* Could be more or less, depending on screen size */
}
/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}


</style>


<body>
  <div class="container" style='border-bottom : 1px solid grey'>
  <div class='panel-body'>
    <div class="row">
      <div class="col-md-3">
        <form method="POST" action="<?php echo base_url() ?>index.php/controller_report">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Cek Your IP Address" name="ip">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" type="submit" name="search">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
          </div>
        </form>
      </div>
      <div class="col-md-3">
                      <?php
            $statusa = "unknown";
            $color = "orange";
            if(isset($_POST['ip'])){
              $ip =   $_POST['ip'];
              exec("ping -n 3 $ip", $output, $status);
              
              if($output[2] == "Request timed out."){
                $statusa = "Mati";
                $color = "red";
              }else{
                $statusa = "Hidup";
                $color = "green";
              }
              
              echo "<b>IP : ".$_POST['ip']."</b></br><b style='color : ".$color."'>Status : ".$statusa."</b>";
            }
            
            
            ?>
      </div>
      <?php 
      if(isset($_POST['ip'])){
        echo '
      <div class="col-md-3">
        <!-- Trigger/Open The Modal -->
          <button id="myBtn" class="btn">Open Detail</button>

          <!-- The Modal -->
          <div id="myModal" class="modal">

          <!-- Modal content -->
            <div class="modal-content">
              <span class="close">&times;</span>
                <b>Detail</b>
                </br>
                <p>
                ';
                    
                    for($i = 1; $i < count($output); $i++){
                      echo "<br>";
                      echo $output[$i];
                    }
                    
                echo '
                </p>
            </div>

          </div>
      </div>
      ';
      }
      ?>
    </div>
  </div>
  </div>
    
    
    <div class="col-lg-12">
            <div class="panel-body">
      <div class="col-md-6">
                    <a href='<?php echo base_url() ?>index.php/controller_report/downloadData'><button class="btn"><i class="fa fa-download" ></i> Generate Report</button></a>
              </div>
            <form method="POST" action="<?php echo base_url() ?>index.php/controller_report/search">
                
        <div class="col-md-3 ">
                    <div class="nav nav-pills flex-column flex-sm-row">
                        <select class="form-control" name="pilihan">
                            <option value="Serialnumber">SerialNumber</option>
                        </select>
            
                    </div>
                </div>
                <div class="col-md-3  input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search..." name="key">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" type="submit" name="search">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                </div>
            </form>
            </div>
            <div class="panel panel-success">
                <div class="panel-heading">
                    <strong>Item List</strong> | Total: <?php echo $jumlah; ?> 
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Serial Number</th>
                    <th>Hardware Resource</th>
                                    <th>Merek</th>
                                    <th>Tipe</th>
                                    <th>MAC Address</th>
                                    <th>IP Address</th>
                    <th>Tanggal Masuk</th>
                                    <th>Action</th>
                  </tr>
                            </thead>
                            <tbody>
                              <?php foreach ($barang as $key) { ?>
                                <tr>
                                      <td><?php echo $key->Serialnumber; ?></td>
                                      <td><?php echo $key->JenisBuku; ?></td>
                                        <td><?php echo $key->Merek; ?></td>
                                        <td><?php echo $key->Tipe; ?></td>
                                        <td><?php echo $key->Mac; ?></td>
                                        <td><?php echo $key->Ip; ?></td>
                                      <td><?php echo $key->Tglmasuk; ?></td>
                                      <td><?php echo anchor('controller_report/view/'.$key->Serialnumber, "<i class=\"fa fa-eye\"></i>"); ?></td>
                                  </tr> 
                              <?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
      <?php echo $paging ?>
    </div>
</body>

<script>
  // Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

</script>

