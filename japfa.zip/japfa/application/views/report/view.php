<body>
                
            <div class="panel panel-success">
                <!-- /.panel-heading -->
                <div class="panel-body">    
                    <div class="table-responsive">
                        <table class="table table-striped table-condensed">
                    
                            <?php foreach ($barang as $key) { ?>
                                <tr>
                                    <th>Serial Number</th>
                                    <td><?= $key->Serialnumber; ?></td></tr>
                                <tr>
                                    <th>Hardware Resource</th>
                                    <td><?php echo $key->IDJenis; ?></td></tr>
                                <tr>
                                    <th>Merek</th>
                                    <td><?php echo $key->Merek; ?></td></tr>
                                <tr>
                                    <th>Tipe</th>
                                    <td><?php echo $key->Tipe; ?></td></tr>
                                <tr>
                                    <th>MAC Address</th>
                                    <td><?php echo $key->Mac; ?></td></tr>
                                <tr>
                                    <th>IP Address</th>
                                    <td><?php echo $key->Ip; ?></td></tr>
                                <tr>
                                    <th>Tanggal Masuk</th>
                                    <td><?php echo $key->Tglmasuk; ?></td></tr>
                                <tr>
                                    <th>Saat Ini Sudah  </th><td><?= date('Y-m-d') - ($key->Tglmasuk) ?> Tahun </td>

                                </tr>
                              <?php } ?>
                            </tbody>
                        </table>
                    </div>
                                <!-- /.table-responsive -->
                </div>
                            <!-- /.panel-body -->
            </div>
                        <!-- /.panel -->
        </div>
    <div>
    	<?php echo anchor('controller_report/index','Back', 'class="btn btn-outline btn-danger btn-xs"') ?>
    </div>
</body>