<?php 
	include_once("PHP_XLSXWriter/xlsxwriter.class.php");

	ini_set('display_errors', 0);
	ini_set('log_errors', 1);
	error_reporting(E_ALL & ~E_NOTICE);
	$filename = "Data Infrastruktur Server dan Network (".date("Y-m-d H:i:s").").xlsx";
header('Content-disposition: attachment; filename="' .XLSXWriter::sanitize_filename($filename). '"');
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate');
header('Pragma: public');
$jam = date("H:i:s");

$header = array(
	''=>'string',//text
  	'Generated At'=>'string',
  	$jam =>'string'
);
$rows = [];

$namemember = 'unknown';

	foreach($alldata as $row){
		foreach($datamember as $eachmember){
			if($eachmember->Serialnumber == $row->Serialnumber){
				$namemember = $eachmember->NamaMember;
			}
		}
		
      	array_push($rows,array($no,$row->Serialnumber,$row->IDJenis,$row->Merek,$row->Tipe,$row->Mac,$row->Ip,$row->Tglmasuk,$row->JenisBuku,$row->tipe,$namemember));
    	$no++;
    }

$writer = new XLSXWriter();
$writer->setAuthor('Panerus UNS');
$writer->writeSheetHeader('Sheet1',$header,$col_opt=['widths'=>[10,40,20],'supress_row'=>true]);
$writer->writeSheetRow('Sheet1',array("No.","Serial Number","Jenis","Merek","Tipe","Mac","Ip","Tglmasuk","JenisBuku","Tipe","Owner"));
foreach($rows as $row){
	$writer->writeSheetRow('Sheet1', $row);
}
$writer->writeToStdOut();
//$writer->writeToFile('example.xlsx');
//echo $writer->writeToString();
exit(0);
?>