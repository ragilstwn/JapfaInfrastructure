<div class="panel-heading">
     <h3 class="panel-title">Japfa Officer Login</h3>
</div>
<div class="panel-body">
    <?= $this->session->flashdata('message');?>
    <form role="form" method="POST" action= "<?php echo base_url() ?>index.php/controller_auth/login">
    <fieldset>
        <div class="form-group">
            <input class="form-control" placeholder="Username" name="username" type="text" autofocus>
        </div>
        <div class="form-group">
            <input class="form-control" placeholder="Password" name="password" type="password" value="">
        </div>
        <div class="checkbox">
        <label>
            <input name="remember" type="checkbox" value="" disabled>guest | 12345 if you guest<br>
        </label>
        </div>
        <br>
        <button class="btn btn-lg btn-success btn-block" type="submit" name="submit">Sign in</button>
       <br><p style="text-align: center"> Baru bergabung?<a href="<?php echo base_url('index.php/Controller_auth/registration');?>">Register</a></p>
    </fieldset>
    </form>
</div>