<?php  
	Class Controller_barang extends CI_Controller{

		function __construct(){
			parent::__construct();
			$this->load->model('model_barang');
			$this->load->model('model_jenis');
			ceklogin();
		}

		function index(){
			ceklogin();
			$this->load->library('pagination');
			$config['base_url'] = base_url().'index.php/controller_barang/index';
			$config['total_rows'] = $this->model_barang->tampilData()->num_rows();
			$config['per_page'] = 5;
			$this->pagination->initialize($config);
			
			$data['paging'] = $this->pagination->create_links();
			$offset = $this->uri->segment(3);
			$data['barang'] = $this->model_barang->tampilDataPaging($offset, $config['per_page']);
			$data['jumlah'] = $this->model_barang->tampilData()->num_rows();

			$this->template->load('template','barang/index', $data);
		}

		function add(){
			ceklogin();
			if (isset($_POST['submit'])) {
				$this->model_barang->simpanData();
				redirect('controller_barang');
			} else {
				$data['jenis'] = $this->model_jenis->tampilData()->result();
				$this->template->load('template','barang/inputserver',$data);
				$data['Tglmasuk'] = date('Y-m-d');
			}
		}
			function addnet(){
			ceklogin();
			if (isset($_POST['submit'])) {
				$this->model_barang->simpanData();
				redirect('controller_barang');
			} else {
				$data['jenis'] = $this->model_jenis->tampilData()->result();
				$data['Tglmasuk'] = date('Y-m-d');
				$this->template->load('template','barang/inputnet',$data);
			}
		}

		function delete(){
			ceklogin();
			$id = $this->uri->segment(3);
			$this->model_barang->hapusData($id);
			redirect('controller_barang');
		}

		function edit(){
			ceklogin();
			if (isset($_POST['submit'])) {
				$this->model_barang->updateData();
				redirect('controller_barang');
			} else {
				$id = $this->uri->segment(3);
				$data['barang'] = $this->model_barang->dataPerBarang($id);
				$data['jenis'] = $this->model_jenis->tampilData()->result();
				$data['Tglmasuk'] = date('Y-m-d');
				$this->template->load('template','barang/edit',$data);
			}
		}

		function search(){
			ceklogin();
			if (isset($_POST['search'])) {
				$pilihan = $this->input->post('pilihan');
				$key = $this->input->post('key');
			}
			if (empty($key)) {
				redirect('controller_barang');
			}
			$data['barang'] = $this->model_barang->searchData($pilihan,$key);
			$data['jumlah'] = $this->model_barang->searchByID($pilihan,$key)->num_rows();
			$this->template->load('template','barang/searchresult',$data);

			
		}
	}


?>