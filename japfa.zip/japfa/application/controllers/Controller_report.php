<?php  
	Class Controller_report extends CI_Controller{

		function __construct(){
			parent::__construct();
			$this->load->model('model_barang');
			$this->load->model('model_jenis');
			$this->load->model('model_member');
			ceklogin();
			$this->load->helper('url');
		}
		
		function downloadData(){
			$data['alldata'] = $this->model_barang->all();
			$data['datamember'] = $this->model_member->all();
			#$this->load->view('report/coba',$data);
			$this->template->load('template','report/download', $data);
			
		}

		function index(){
			ceklogin();
			$this->load->library('pagination');
			$config['base_url'] = base_url().'index.php/controller_report/index';
			$config['total_rows'] = $this->model_barang->tampilData()->num_rows();
			$config['per_page'] = 5;
			$this->pagination->initialize($config);
			
			$data['paging'] = $this->pagination->create_links();
			$offset = $this->uri->segment(3);
			$data['barang'] = $this->model_barang->tampilDataPaging($offset, $config['per_page']);
			$data['jumlah'] = $this->model_barang->tampilData()->num_rows();
			

			$this->template->load('template','report/index', $data);
			
			
		}

		function search(){
			ceklogin();
			if (isset($_POST['search'])) {
				$pilihan = $this->input->post('pilihan');
				$key = $this->input->post('key');
			}
			if (empty($key)) {
				redirect('controller_report');
			}
			$data['barang'] = $this->model_barang->searchData($pilihan,$key);
			$data['jumlah'] = $this->model_barang->searchByID($pilihan,$key)->num_rows();
			$this->template->load('template','report/searchresult',$data);

			
		}
	function view($Serialnumber){
		$data['barang'] = $this->model_barang->viewbarang($Serialnumber);
		$this->template->load('template','report/view',$data);

		
		
	
}

}
?>