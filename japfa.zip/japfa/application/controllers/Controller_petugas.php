<?php  
	Class Controller_barang extends CI_Controller{


			function __construct(){
				parent::__construct();
				$this->load->model('model_petugas');
				ceklogin();
			}

		function index(){
			ceklogin();
			$this->load->library('pagination');
			$config['base_url'] = base_url().'index.php/controller_petugas/index';
			$config['total_rows'] = $this->model_petugas->getAllData()->num_rows();
			$config['per_page'] = 5;
			$this->pagination->initialize($config);
			
			$data['paging'] = $this->pagination->create_links();
			$offset = $this->uri->segment(3);
			$data['petugas'] = $this->model_petugas->tampilDataPaging($offset, $config['per_page']);
			$data['jumlah'] = $this->model_petugas->getAllData()->num_rows();

			$this->template->load('template','petugas/index', $data);
		}

		function add(){
			ceklogin();
			if (isset($_POST['submit'])) {
				$this->model_member->simpanData();
				redirect('controller_petugas');
			} else {
				$this->template->load('template','petugas/input',$data);
			}
		}
		function delete(){
			ceklogin();
			$id = $this->uri->segment(3);
			$this->model_petugas->hapusData($id);
			redirect('controller_petugas');
		}

		function edit(){
			ceklogin();
			if (isset($_POST['submit'])) {
				$this->model_member->updateData();
				redirect('controller_petugas');
			} else {
				$id = $this->uri->segment(3);
				$data['petugas'] = $this->model_petugas->dataPerBarang($id);
				$this->template->load('template','petugas/edit',$data);
			}
		}

		function search(){
			ceklogin();
			if (isset($_POST['search'])) {
				$pilihan = $this->input->post('pilihan');
				$key = $this->input->post('key');
			}
			if (empty($key)) {
				redirect('controller_petugas');
			}
			$data['petugas'] = $this->model_petugas->searchData($pilihan,$key);
			$data['jumlah'] = $this->model_petugas->searchByID($pilihan,$key)->num_rows();
			$this->template->load('template','petugas/searchresult',$data);
		}

}
?>