<?php 

	class Controller_auth extends CI_Controller{
		
		function __construct(){
			parent::__construct();
			$this->load->library('form_validation');
			$this->load->model('model_petugas');
			$this->load->library('form_validation');
		}

		function index(){
			if ($this->session->LoginBang == 'oke') {
				redirect('controller_home');
			} else {
				$this->template->load('login','form_login');
			}
		}

		function login(){
			if (isset($_POST['submit'])) {
				if ($this->model_petugas->login() == 1) {
					$this->session->LoginBang = 'oke';
					$_SESSION['nama'] = $this->model_petugas->namaPetugas();
					$_SESSION['id'] = $this->model_petugas->idPetugas();
					$_SESSION['role'] = $this->model_petugas->role();
					redirect('controller_home');
				} else {
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">You Got the Wrong username and Password, Please Try Again!</div>');
						redirect('Controller_auth');
				}
			} else {
				$this->template->load('login','form_login');
			}
		}

	function registration(){
		$this->form_validation->set_rules('Firstname', 'Firstname', 'required|trim');
		$this->form_validation->set_rules('Lastname', 'Lastname', 'required|trim');
		$this->form_validation->set_rules('NamaPetugas', 'NamaPetugas', 'required|trim');
		$this->form_validation->set_rules('IDPetugas', 'IDPetugas', 'required|trim');
		$this->form_validation->set_rules('email','Email', 'required|trim|valid_email|is_unique[petugas.email]' ,
				['is_unique' => 'This email has already registered']);
		$this->form_validation->set_rules('Username', 'Username', 'required|trim');
		$this->form_validation->set_rules('password1','Password', 'required|trim|min_length[5]|matches[password2]',
			['matches' => 'password dont match!', 'min_length' => 'password to short!']);
		$this->form_validation->set_rules('password2','Password', 'required|trim|matches[password1]');

		if ($this->form_validation->run() == false){
		$this->template->load('registration','form_regis');
	}else{
		$data = [
			'Firstname' =>htmlspecialchars($this->input->post('Firstname', true)),
			'Lastname'=>htmlspecialchars($this->input->post('Lastname', true)),
			'NamaPetugas'=>htmlspecialchars($this->input->post('NamaPetugas', true)),
			'IDPetugas'=>htmlspecialchars($this->input->post('IDPetugas', true)),
			'email'=>htmlspecialchars($this->input->post('email', true)),
			'Username'=>htmlspecialchars($this->input->post('Username', true)),
			'password' => $this->input->post('password1'),
			'role' => "Karyawan",
			'date_created' => date('Y-mm-dd')
		];

		$this->db->insert('petugas', $data);
		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Congratulation your account has been created. Please Login</div>');
		redirect('Controller_auth/login');
	}
	}

		function logout(){
			session_destroy();
			redirect('controller_auth/login');
		}
	}
?>