<?php  
	Class Controller_karyawan extends CI_Controller{

		function __construct(){
			parent::__construct();
			$this->load->model('model_petugas');
			$this->load->model('model_karyawan');
			ceklogin();
			$this->load->helper('url');
		}
	function index(){
			ceklogin();
			$_SESSION['email'] = $this->model_karyawan->email();
			$data['petugas'] = $this->model_karyawan->all();
			
			$config['base_url'] = base_url().'index.php/controller_karyawan/index';
			$this->template->load('template','karyawan/index',$data);
		}

		function view(){
		$data['karyawan'] = $this->model_karyawan->viewkaryawan();
		$this->template->load('template','karyawan/view',$data);
		}

		function add(){
			ceklogin();
			if (isset($_POST['submit'])) {
				// target direktori fileupload
				$target_dir = "c:/xampp/htdocs/japfa/assets/img/profile/";
				
				// baca nama file upload
				$image = $_FILES["Image"]["name"];

				// menggabungkan target dir dengan nama file
				$target_file = $target_dir . basename($image);

				// proses upload
				move_uploaded_file($_FILES["Image"]["tmp_name"], $target_file);
				$this->model_karyawan->simpanData($image);
				redirect('controller_karyawan');
			} else {
				$data['petugas'] = $this->model_petugas->tampilData();
				$this->template->load('template','karyawan/input',$data);
			}
		}


		function Datakaryawan(){
			ceklogin();
			$this->load->library('pagination');
			$config['base_url'] = base_url().'index.php/controller_karyawan/Datakaryawan';
			$config['total_rows'] = $this->model_karyawan->tampilData1()->num_rows();
			$config['per_page'] = 5;
			$this->pagination->initialize($config);
			
			$data['paging'] = $this->pagination->create_links();
			$offset = $this->uri->segment(3);
			$data['karyawan'] = $this->model_karyawan->tampilDataPaging($offset, $config['per_page']);
			$data['jumlah'] = $this->model_karyawan->tampilData1()->num_rows();

			$this->template->load('template','karyawan/Datakaryawan', $data);
		}

		function edit(){
			ceklogin();
			if (isset($_POST['submit'])) {
				// target direktori fileupload
				$target_dir = "c:/xampp/htdocs/japfa/assets/img/profile/";
				
				// baca nama file upload
				$image = $_FILES["Image"]["name"];

				// menggabungkan target dir dengan nama file
				$target_file = $target_dir . basename($image);

				// proses upload
				move_uploaded_file($_FILES["Image"]["tmp_name"], $target_file);
				$this->model_karyawan->updateDatakaryawan($image);
				redirect('controller_karyawan');
			} else {
				$id = $this->uri->segment(3);
				$data['karyawan'] = $this->model_karyawan->tampilData();
				$this->template->load('template','karyawan/edit',$data);
			}
		}

		function delete(){
			ceklogin();
			$id = $this->uri->segment(3);
			$this->model_karyawan->hapusData($id);
			redirect('controller_karyawan');
		}

		function search(){
			ceklogin();
			if (isset($_POST['search'])) {
				$pilihan = $this->input->post('pilihan');
				$key = $this->input->post('key');
			}
			if (empty($key)) {
				redirect('controller_karyawan');
			}
			$data['karyawan'] = $this->model_karyawan->searchData($pilihan,$key);
			$data['jumlah'] = $this->model_karyawan->searchByID($pilihan,$key)->num_rows();
			$this->template->load('template','karyawan/search',$data);
		}

		function editadmin(){
			ceklogin();
			if (isset($_POST['submit'])) {
				// target direktori fileupload
				$target_dir = "c:/xampp/htdocs/japfa/assets/img/profile/";
				
				// baca nama file upload
				$image = $_FILES["Image"]["name"];

				// menggabungkan target dir dengan nama file
				$target_file = $target_dir . basename($image);

				// proses upload
				move_uploaded_file($_FILES["Image"]["tmp_name"], $target_file);
				$this->model_karyawan->updateData($image);
				redirect('controller_karyawan/Datakaryawan');
			} else {
				$id = $this->uri->segment(3);
				$data['karyawan'] = $this->model_karyawan->dataPerKaryawan($id);
				$data['karyawan'] = $this->model_karyawan->tampilData1();
				$this->template->load('template','karyawan/editadmin',$data);
			}
		}

		function downloadData(){
			$data['alldata'] = $this->model_karyawan->all();
			$data['datakaryawan'] = $this->model_petugas->all();
			#$this->load->view('report/coba',$data);
			$this->template->load('template','karyawan/download', $data);
			
		}





}
?>